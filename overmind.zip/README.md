Navigate to split-or-steal
Click on the drop-menu
Select then right click split-or-steal.move1
Click on file on the top left hand corner
Select New Text File
NOTE: you can use CTRL+O for (Window/Linux) and CMD+O for MacOS
Untitled text file will with Select Language ....
Click on Select Language link dropdown window will open with different keywords in colors
Type something on the drop down window
different keywords will appear with colors.

NOTE made the test .move1 since my macos has different Github will delete it as soon as I finished this test.https://github.com/chrizteroo

my personal github is github.com/coladimeji 
